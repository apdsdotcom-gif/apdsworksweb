---
title: "Memilih Warna Pastel untuk Desain yang Lebih Nyaman"
date: "2025-01-02"
excerpt: "Panduan memilih warna pastel agar desain terasa lembut, konsisten, dan modern."
cover: "/images/blog-covers/warna-pastel.webp"
tags: ["color","design"]
---
Konten artikel versi awal. Nanti bisa kamu ganti sesuai kebutuhan.