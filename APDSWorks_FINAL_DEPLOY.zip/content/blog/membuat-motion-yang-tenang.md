---
title: "Membuat Motion yang Tenang: Pendekatan Minimal untuk Visual Modern"
date: "2025-01-01"
excerpt: "Cara merancang motion yang lembut, rapi, dan tidak mengganggu fokus visual."
cover: "/images/blog-covers/motion-tenang.webp"
tags: ["motion","design"]
---
Konten artikel versi awal. Nanti bisa kamu ganti sesuai kebutuhan.