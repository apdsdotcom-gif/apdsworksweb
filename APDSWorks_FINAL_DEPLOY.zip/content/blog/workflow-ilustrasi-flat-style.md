---
title: "Workflow Sederhana untuk Ilustrasi Flat Style"
date: "2025-01-03"
excerpt: "Langkah-langkah membuat ilustrasi flat style yang bersih dan detail tanpa proses rumit."
cover: "/images/blog-covers/flat-style.webp"
tags: ["illustration","workflow"]
---
Konten artikel versi awal. Nanti bisa kamu ganti sesuai kebutuhan.