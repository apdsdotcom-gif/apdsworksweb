---
title: "Eksperimen Visual dengan Bentuk Organik"
excerpt: "Eksplorasi bentuk bebas dan kombinasi warna lembut yang menjadi dasar style APDSWorks."
cover: "/images/project-covers/project3.webp"
tools: ["Figma", "Procreate"]
---
Deskripsi karya versi awal. Tambahkan variasi warna & bentuk blob."
