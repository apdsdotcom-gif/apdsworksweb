---
title: "Explorasi Motion Logo Pastel"
excerpt: "Eksperimen membuat logo bergerak dengan pendekatan warna pastel dan ritme yang lembut."
cover: "/images/project-covers/project1.webp"
tools: ["After Effects", "Illustrator"]
---
Deskripsi karya versi awal. Bisa kamu tambahkan GIF atau video nantinya.