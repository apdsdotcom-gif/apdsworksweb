---
title: "Ilustrasi Flat Style untuk Dashboard Modern"
excerpt: "Set ikon dan ilustrasi flat que ringan untuk UI dashboard bertema calm-tech."
cover: "/images/project-covers/project2.webp"
tools: ["Figma", "Illustrator"]
---
Deskripsi karya versi awal. Tambahkan studi ikon & contoh UI.